﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LSys;
using Geometry;

public class Test : MonoBehaviour {

    public Material material;

	// Use this for initialization
	void Awake () {

        Dictionary<string, List<Rule>> grammar = new Dictionary<string, List<Rule>>();
        grammar["P"] = new List<Rule>();
        grammar["P"].Add(new Rule(1.0f, "I+[P+f]--//[--L]I[++L]-[Pf]++Pf"));
        grammar["I"] = new List<Rule>();
        grammar["I"].Add(new Rule(1.0f, "FS[//&&L][//^^L]FS"));
        grammar["S"] = new List<Rule>();
        grammar["S"].Add(new Rule(1.0f, "SFS"));
        grammar["E"] = new List<Rule>();
        grammar["E"].Add(new Rule(1.0f, "FF"));

        LSystem LS = new LSystem("P", grammar);
        LinkedListA<string> ll = LS.DoIterations(5);
        Turtle turtle = new Turtle(null, 18);
        turtle.RenderSymbols(ll);

        MeshGenerator mg = turtle.meshGenerator;
        GetComponent<MeshFilter>().mesh = mg.Generate();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
